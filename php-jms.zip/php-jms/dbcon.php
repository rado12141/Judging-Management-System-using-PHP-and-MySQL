<?php
$conn = new PDO('mysql:host=localhost;dbname=jms_db', 'root', '');
?>
