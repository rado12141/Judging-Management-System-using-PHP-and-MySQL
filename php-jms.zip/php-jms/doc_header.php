            <table>
      
              <tr>
              <td><center><img src="uploads/<?php echo $company_logo; ?>" width="50" height="50" /> </center></td>
             </tr>
             
             <tr>
              <td>
              <center>
              <font size="5"><strong><?php echo $company_name; ?></strong></font><br />
                <font size="2"><?php echo $company_address; ?></font> <br />
                <font size="2"><?php echo $company_telephone; ?> &middot;
                 <a href="<?php echo $company_website; ?>" target="_blank"><?php echo $company_website; ?></a> &middot; 
                
                <?php echo $company_email; ?><br />
                </font>
              </center>
              </td>
              </tr>
          
              </table>