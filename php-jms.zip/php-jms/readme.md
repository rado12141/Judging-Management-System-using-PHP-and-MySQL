

# Orignal Developer
**Emilio B. Magtolis Jr.**
**emiloimagtolis@gmail.com**
*Downloaded @ http://freeproject24.com/php-judging-system-with-source-code-freeproject24/*

*This is just a modified version/copy only and uploaded @ https://www.sourcecodester.com/*